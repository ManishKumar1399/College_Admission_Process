package com.newgen.model;

public class Student {

	private String stuName;
	private String stuFather;
	private String date;
	private String email;
	private String mob;
	private String gender;
	private String address;
	private String city;

	private String country;
	private String Course;
	private int amount;
	

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(String stuName, String stuFather, String date, String email, String mob, String gender, String address,
			String city, String country, String course, int amount) {
		super();
		this.stuName = stuName;
		this.stuFather = stuFather;
		this.date = date;
		this.email = email;
		this.mob = mob;
		this.gender = gender;
		this.address = address;
		this.city = city;
		this.country = country;
		Course = course;
		this.amount = amount;
	
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public String getStuFather() {
		return stuFather;
	}

	public void setStuFather(String stuFather) {
		this.stuFather = stuFather;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMob() {
		return mob;
	}

	public void setMob(String mob) {
		this.mob = mob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCourse() {
		return Course;
	}

	public void setCourse(String course) {
		Course = course;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}



}


