package com.newgen.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.DriverManager;


public class DbConn {
	
	static Connection con;
	
	public static Connection getConn() {
		
		try {
			DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
			con = DriverManager.getConnection("jdbc:sqlserver://192.168.136.212;databaseName=db49;user=user49;password=db49");
		} catch (Exception e) {
			System.out.println("Error in Connection : "+e);
		}
		return con;
	}

}
