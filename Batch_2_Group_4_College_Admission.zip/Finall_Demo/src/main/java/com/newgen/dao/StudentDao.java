package com.newgen.dao;

import java.util.ArrayList;

import com.newgen.model.Student;

public interface StudentDao {
	
	public int addStudent(Student stu);
	public ArrayList<Student> getAllStudents();
	public Student getStudentById(int id);
	public Student getList();

}
