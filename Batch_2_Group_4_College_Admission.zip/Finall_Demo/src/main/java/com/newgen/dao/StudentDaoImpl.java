package com.newgen.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.newgen.model.DbConn;
import com.newgen.model.Student;

public class StudentDaoImpl implements StudentDao{

	
	@Override
	public int addStudent(Student stu) {
		int result =0 ;
		try {
			Connection con = DbConn.getConn();
			PreparedStatement ps = con.prepareStatement("insert into student values(?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, stu.getStuName());
			ps.setString(2, stu.getStuFather());
			ps.setString(3, stu.getDate());
			ps.setString(4, stu.getEmail());
			ps.setString(5, stu.getMob());
			ps.setString(6, stu.getGender());
			ps.setString(7, stu.getAddress());
			ps.setString(8, stu.getCity());
			ps.setString(9, stu.getCountry());
			ps.setString(10, stu.getCourse());
			ps.setInt(11, stu.getAmount());
			
			
			result = ps.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("Error in Add Student : "+e);
		}
		return result;
	}

	@Override
	public ArrayList<Student> getAllStudents() {
		ArrayList<Student> stuList  = new ArrayList<Student>();
				
		try {
			Connection con = DbConn.getConn();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from student");
			while(rs.next()) {
				Student stu = new Student();
				stu.setStuName(rs.getString(1));
				stu.setStuFather(rs.getString(2));;
				stu.setDate(rs.getString(3));
				stu.setEmail(rs.getString(4));
				stu.setMob(rs.getString(5));
				stu.setGender(rs.getString(6));
				stu.setAddress(rs.getString(7));
				stu.setCity(rs.getString(8));
				stu.setCountry(rs.getString(9));
				stu.setCourse(rs.getString(10));
				stu.setAmount(rs.getInt(11));
				stuList.add(stu);
			}
		} catch (Exception e) {
			System.out.println("Error in get All Student : "+e);
		}
		return stuList;
	}

	@Override
	public Student getStudentById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Student getList() {
		// TODO Auto-generated method stub
		return null;
	}

}
