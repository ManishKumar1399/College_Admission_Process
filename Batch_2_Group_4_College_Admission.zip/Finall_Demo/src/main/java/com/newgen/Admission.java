package com.newgen;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Admission {
	public static void main(String[] args) throws SQLException {
		
		
		//load a Driver
		DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
    
		//Connection to the database
		Connection connection = DriverManager.getConnection("jdbc:sqlserver://192.168.136.212;databaseName=db49;user=user49;password=db49");
		System.out.println("Connected");
		
		//3. create a statement or Query
		Statement st=connection.createStatement();
		
		//4.Execute a Statement or Query
//		st.execute("create table java(id integer, sname varchar(30))");
//		System.out.println("Table Created");
		

		//5.Handle The Exception Using 
		
	
	
	}

}
